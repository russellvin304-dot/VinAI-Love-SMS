# VinAI Love SMS — Android APK project

Huu ni **mradi wa source code**, si APK iliyokwisha kujengwa. Workflow ya GitHub Actions inaweza kujenga APK bila Android Studio kwenye simu yako.

## Njia ya kujenga APK kwa kutumia simu

1. Pakua na fungua ZIP hii.
2. Ingia GitHub na utengeneze repository mpya inayoitwa `VinAI-Love-SMS` (iwe Public au Private).
3. Pakia **maudhui yote ya folder hii** kwenye repository, ukihakikisha `.github/workflows/build-apk.yml` imepakia pia.
4. Fungua repository > **Actions** > **Build VinAI Love SMS APK** > **Run workflow**.
5. Subiri build ikamilike ikiwa na alama ya kijani.
6. Fungua run iliyokamilika, nenda sehemu ya **Artifacts**, kisha pakua `VinAI-Love-SMS-debug-apk`.
7. Fungua ZIP ya artifact na utoe `app-debug.apk`. Gusa APK ili ku-install. Android inaweza kukuomba uruhusu install kutoka browser/files app.

## Kumbuka
- Hii ni debug APK ya majaribio; haijasainiwa kwa ajili ya kusambazwa rasmi Play Store.
- Jenga APK kwenye GitHub Actions; faili la APK halijatengenezwa ndani ya ZIP hii.
- App inafungua HTML iliyowekwa ndani yake. Baadhi ya share features zinaweza kutegemea apps nyingine kama WhatsApp.
